<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'mood';
$modulename = '新闻心情';
$introduce = '新闻心情模块';
$author = 'phpcms team';
$authorsite = 'http://www.phpcms.cn';
$authoremail = '';
?>