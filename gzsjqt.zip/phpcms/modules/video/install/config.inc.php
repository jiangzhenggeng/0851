<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'video';
$modulename = '视频库管理';
$introduce = '视频库管理';
$author = 'phpcms team';
$authorsite = 'http://www.phpcms.cn';
$authoremail = 'phpcms@snda.com';
?>