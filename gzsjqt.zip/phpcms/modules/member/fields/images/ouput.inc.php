	function images($field, $value) {
		return string2array($value);
	}
