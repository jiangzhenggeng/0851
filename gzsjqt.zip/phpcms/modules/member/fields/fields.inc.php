<?php
$fields = array('text'=>'单行文本',
				'textarea'=>'多行文本',
				'editor'=>'编辑器',
				'box'=>'选项',
				'image'=>'图片',
				'images'=>'多图片',
				'number'=>'数字',
				'datetime'=>'日期和时间',
				'linkage'=>'联动菜单',
				'omnipotent'=>'万能字段',
				'checkmobile'=>'短信验证',
 				);
?>