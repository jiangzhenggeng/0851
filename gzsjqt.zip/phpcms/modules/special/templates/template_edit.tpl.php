<script src="<?php echo JS_PATH;?>colorpicker.js" type="text/javascript" language="javascript"></script>

<?php echo $html?>
<link rel="stylesheet" type="text/css" href="<?php echo CSS_PATH?>admin_visualization.css" />

</body>
</html>