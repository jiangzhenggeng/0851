<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'sms';
$modulename = '短信平台';
$introduce = '短信平台';
$author = 'phpcms team';
$authorsite = 'http://www.phpcms.cn';
$authoremail = '';
?>