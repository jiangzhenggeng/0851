<?php

/*Language Format:
Add a new file(.lang.php) with your module name at /phpcms/languages/
translation save at the array:$LANG
*/
//info_setting.phpcredits

$LANG['addmark'] = '点击标注位置';
$LANG['editmark'] = '修改标注位置';
$LANG['mapmark'] = '地图标注';
$LANG['api_addmark'] = '添加标注';
$LANG['api_resetmap'] = '重置地图';
$LANG['api_changecity'] = '更换城市';
$LANG['api_citylist'] = '城市列表';
$LANG['api_inputcity'] = '输入城市名';
$LANG['api_citysear_submit'] = '确定';
?>