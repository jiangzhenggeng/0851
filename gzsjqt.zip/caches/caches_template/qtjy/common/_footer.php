<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>
<div class="main">
    <div class="studyems027">
        <div class="studyems100">
            <div class="studyems101">
                <p><font color="#dd1200">友情</font>链接</p>
            </div>
            <div class="studyems096">
                <p><a href="http://kr.hujiang.com/" target="_blank">韩语入门</a><a href="http://www.pptok.com/"
                                                                               target="_blank">PPT模板下载</a><a
                        href="http://www.zqnf.com/" target="_blank">作业答案</a><a href="http://kaoyan.koolearn.com"
                                                                               target="_blank">新东方考研</a><a
                        href="http://www.canet.com.cn/" target="_blank">中国会计网</a><a href="http://www.xehedu.com/"
                                                                                    target="_blank">广东自考网</a><a
                        href="http://www.wdlyedu.com/" target="_blank">广州自考网</a><a href="http://xuexiao.51sxue.com/"
                                                                                   target="_blank">学校大全</a><a
                        href="http://www.edu84.com/" target="_blank">报名在线</a><a href="http://www.tedu.cn/"
                                                                                target="_blank">IT培训</a><a
                        href="http://www.zgsydw.com/" target="_blank">事业单位招聘考试 </a><a href="http://www.wenku1.com"
                                                                                      target="_blank">教育文库</a><a
                        href="http://www.xzbu.com/" target="_blank">论文网</a><a href="http://www.bdkssc.com"
                                                                              target="_blank">职称计算机考试</a><a
                        href="http://www.zikao.gd/" target="_blank">广东省自考网</a><a href="http://www.kanzhun.com/"
                                                                                 target="_blank">看准网</a><a
                        href="http://www.jisiedu.com/" target="_blank">月亮岛教育网</a><a href="http://www.258en.com"
                                                                                    target="_blank">英语</a><a
                        href="http://www.topstudy8.com" target="_blank">精品学习吧</a><a href="http://www.71peixun.com"
                                                                                    target="_blank">企业培训网</a><a
                        href="http://www.gebilaoshi.com/" target="_blank">隔壁老师教育网</a><a href="http://www.ybjk.com/"
                                                                                        target="_blank">元贝驾考</a><a
                        href="http://www.kaoyan001.com/" target="_blank">华文考研</a><a href="http://zj.offcn.com"
                                                                                    target="_blank">浙江人事网</a><a
                        href="http://www.66test.com/" target="_blank">66考网</a><a href="http://www.051661.com/"
                                                                                 target="_blank">幼儿教育网</a><a
                        href="http://i1766.com/" target="_blank">读后感</a><a href="http://www.zzyjs.com/" target="_blank">在职研究生网</a><a
                        href="http://www.cn910.net" target="_blank">免费教案</a><a href="http://www.100ksw.com"
                                                                               target="_blank">考试宝典</a><a
                        href="https://m.bosszhipin.com/home/" target="_blank">BOSS直聘</a><a href="http://www.9ask.cn/"
                                                                                           target="_blank">律师咨询</a><a
                        href="http://www.xuexun.com" target="_blank">学讯网</a></p>
            </div>
        </div>
    </div>
</div>
<div class="studyems097">
    <div class="main">
        <div class="studyems098">
            <p><a href="http://www.studyems.com/help_30.html">关于本站</a>&nbsp;&nbsp;<a
                    href="http://www.studyems.com/help_32.html">诚征英才</a>&nbsp;&nbsp;<a
                    href="http://www.studyems.com/help_33.html">广告服务</a>&nbsp;&nbsp;<a
                    href="http://www.studyems.com/help_34.html">招生服务</a>&nbsp;&nbsp;<a
                    href="http://www.studyems.com/help_35.html">免责声明</a>&nbsp;&nbsp;<a
                    href="http://www.studyems.com/help_42.html">分站加盟</a>&nbsp;&nbsp;<a
                    href="http://www.studyems.com/help_41.html">VIP会员</a>&nbsp;&nbsp;<a
                    href="http://www.studyems.com/help_38.html">联系我们</a>&nbsp;&nbsp;<a
                    href="http://www.studyems.com/help_40.html">网站地图</a>&nbsp;&nbsp;<a
                    href="http://www.studyems.com/help_31.html">网站记事</a>&nbsp;&nbsp;</p>
            <div class="studyems099">
                <div class="emsfoot002" style="padding-top:3px;">版权所有 CopyRight 2008-2015 粤ICP备14009694号
                    www.studyems.com, Inc. All Rights Reserved 投诉建议请发邮件到2279008379@qq.com<br>
                    <a href="http://wpa.qq.com/msgrd?v=3&uin=809247782&site=qq&menu=yes" title="点击打开QQ咨询"
                       target="_blank"><IMG src="<?php echo CSS_PATH;?>1/images/qq.gif"> 809247782 （李老师）</a> <a
                            href="http://wpa.qq.com/msgrd?v=3&uin=842399148&site=qq&menu=yes" title="点击打开QQ咨询"
                            target="_blank"><IMG src="<?php echo CSS_PATH;?>1/images/qq.gif"> 842399148 （温老师）</a> <a
                            href="http://wpa.qq.com/msgrd?v=3&uin=2645603372&site=qq&menu=yes" title="点击打开QQ咨询"
                            target="_blank"><IMG src="<?php echo CSS_PATH;?>1/images/qq.gif"> 2645603372 （高老师）</a> <br>
                    VIP咨询、城市加盟、广告位购买 请拔打电话：15915748007（李老师）15918739651（高老师）<br>
                    本站所有课程均为网民自行发布，报名时请自行核查课程真实性，谨防上当受骗，举报邮件2279008379@qq.com。<br>
                    让我们携手共同为中国教育事业的发展做出更多的贡献 <a href="http://www.studyems.com/">《求学快递网》</a>无偿为学习者与教育者搭建免费资源共享信息发布平台<br>
                    <a href="http://www.studyems.com/login.html" target="_blank">免费发布信息</a>,免费招生信息,本站所有资源均来源于各网友上传分享,如果涉及任何版权方面的问题,请与本站联系,详见<a
                            href="http://www.studyems.com/help_36.html">权利声明</a>！
                </div>
            </div>
        </div>
    </div>
</div>
<div style="display:none">
    <script src="../Script/stat.php" language="JavaScript" charset="gb2312"></script>
</div>
</body>
</html>