<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?><div style="float:left; margin-top:-5px;">
    <div style="float:left; margin-top:6px; margin-left:8px; color:#666666;">分享</div>
    <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
        <a class="bds_qzone"></a>
        <a class="bds_renren"></a>
        <a class="bds_hi"></a>
        <a class="bds_baidu"></a>
        <span class="bds_more">更多</span>
        <a class="shareCount"></a>
    </div>
    <script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=541572"></script>
    <script type="text/javascript" id="bdshell_js"></script>
    <script type="text/javascript">document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();</script>
    <!-- Baidu Button END -->
</div>