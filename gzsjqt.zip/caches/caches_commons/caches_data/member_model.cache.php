<?php
return array (
  10 => 
  array (
    'modelid' => '10',
    'siteid' => '1',
    'name' => '普通会员',
    'description' => '普通会员',
    'tablename' => 'member_detail',
    'setting' => '',
    'addtime' => '0',
    'items' => '0',
    'enablesearch' => '1',
    'disabled' => '0',
    'default_style' => '',
    'category_template' => '',
    'list_template' => '',
    'show_template' => '',
    'js_template' => '',
    'admin_list_template' => '',
    'member_add_template' => '',
    'member_list_template' => '',
    'sort' => '0',
    'type' => '2',
  ),
);
?>