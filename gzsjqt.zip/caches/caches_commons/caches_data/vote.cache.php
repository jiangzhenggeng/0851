<?php
return array (
  1 => 
  array (
    'default_style' => 'default',
    'vote_tp_template' => 'vote_tp',
    'allowguest' => '1',
    'enabled' => '1',
    'interval' => '1',
    'credit' => '1',
  ),
);
?>