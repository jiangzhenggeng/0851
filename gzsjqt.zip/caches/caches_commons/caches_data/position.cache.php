<?php
return array (
  2 => 
  array (
    'posid' => '2',
    'modelid' => '0',
    'catid' => '0',
    'name' => '首页头条banner推荐',
    'maxnum' => '20',
    'extention' => '',
    'listorder' => '4',
    'siteid' => '0',
    'thumb' => '',
  ),
  1 => 
  array (
    'posid' => '1',
    'modelid' => '0',
    'catid' => '0',
    'name' => '首页头条banner下边滚动',
    'maxnum' => '20',
    'extention' => '',
    'listorder' => '1',
    'siteid' => '0',
    'thumb' => '',
  ),
  18 => 
  array (
    'posid' => '18',
    'modelid' => '0',
    'catid' => '0',
    'name' => '首页外语培训推荐',
    'maxnum' => '20',
    'extention' => '',
    'listorder' => '0',
    'siteid' => '0',
    'thumb' => '',
  ),
);
?>