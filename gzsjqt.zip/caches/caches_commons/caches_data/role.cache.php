<?php
return array (
  1 => '超级管理员',
  8 => '网站管理员',
);
?>