<?php
return array (
  1 => 
  array (
    'siteid' => '1',
    'name' => '贵州特种作业培训网/贵州特种作业培训中心',
    'dirname' => '',
    'domain' => 'http://www.jiangzg.com/gzsjqt/',
    'site_title' => '贵州特种作业培训网/贵州特种作业培训中心',
    'keywords' => '贵州特种作业培训网/贵州特种作业培训中心',
    'description' => '贵州特种作业培训网/贵州特种作业培训中心由贵州黔通教育权威发布全省特种作业培训信息，贵州黔通教育作为贵州省专业开展特种作业培训，特种作业考核的龙头机构，贵州黔通教育十年专注从事特种作业培训，目前已在贵州省全省培训特种操作人员上万名。',
    'release_point' => '',
    'default_style' => 'qtjy',
    'template' => 'qtjy',
    'setting' => '{"upload_maxsize":"2048","upload_allowext":"jpg|jpeg|gif|bmp|png|doc|docx|xls|xlsx|ppt|pptx|pdf|txt|rar|zip|swf","watermark_enable":"1","watermark_minwidth":"300","watermark_minheight":"300","watermark_img":"statics\\/images\\/water\\/\\/mark.png","watermark_pct":"85","watermark_quality":"80","watermark_pos":"9"}',
    'uuid' => 'c5056f7c-4666-11e6-9b6e-00163e004e4b',
    'url' => 'http://www.jiangzg.com/gzsjqt/',
  ),
);
?>