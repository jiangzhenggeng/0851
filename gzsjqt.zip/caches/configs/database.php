<?php

return array (
	'default' => array (
		'hostname' => 'qdm158444482.my3w.com',
		'port' => 3306,
		'database' => 'qdm158444482_db',
		'username' => 'qdm158444482',
		'password' => 'jzg597567953',
		'tablepre' => 'v92_',
		'charset' => 'utf8',
		'type' => 'mysqli',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>