<?php
return array (
  13 => 
  array (
    'typeid' => '53',
    'name' => '教师模型',
    'sort' => '0',
  ),
  14 => 
  array (
    'typeid' => '54',
    'name' => '学校模型',
    'sort' => '0',
  ),
  15 => 
  array (
    'typeid' => '55',
    'name' => '文章模型',
    'sort' => '0',
  ),
  1 => 
  array (
    'typeid' => '1',
    'name' => '新闻',
    'sort' => '1',
  ),
  'special' => 
  array (
    'typeid' => '52',
    'name' => '专题',
  ),
);
?>